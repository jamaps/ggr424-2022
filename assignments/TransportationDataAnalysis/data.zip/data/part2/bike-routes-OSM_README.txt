bike_routes_OSM.geojson README

data is from OpenStreetMap, and thus might be incomplete or incorrectly tagged in some areas

type:
"L" = bike lane (usually just a painted divider)
"P" = separate path/trail (usually in a park)
"S" = shared with vehicles (e.g. sharrow, shared with public transit)
"T" = cycle-track (usually has a barrier/curb separating bike lanes from traffic lanes)
"O" = other
